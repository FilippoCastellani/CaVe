In this folder there are three matlab scripts and 3 matlab data files.

SCRIPTS
1) MRI_Lesion_Segmentation_20 	is the official script for our assignment
2) MRI..._and_noise 		is the same as before but provides the possibility to apply noise
3) MRI..._axial 		is the same as the previous two but provides the possibility to perform segmentation on axial slices.

DATA FILES
MRIdata		=	contains the assignment datas
camera_settings	= 	contains datas for visualization of segmentation
segmented_volume= 	contains the final result of script (1) applied on datas 